// const TrezSmsClient = require("trez-sms-client");
// const client = new TrezSmsClient("ramtinzand", "Ramtin1995d");
// // exports.sendSms = () => {
// //     console.log("first")
// //   client
// //     .autoSendCode("09138433385", "کد ورود به برنامه کرمان آتاری")
// //     .then((messageId) => {
// //       console.log("Sent Message ID: " + messageId);
// //     })
// //     .catch((error) => console.log(error));
// // };

// // client
// //   .autoSendCode("09138433385", "کد ورود به برنامه کرمان آتاری")
// //   .then((messageId) => {
// //     console.log("Sent Message ID: " + messageId);
// //   })
// //   .catch((error) => console.log(error));

// // client.checkCode("09138433385", "8")
// //     .then((isValid) => {
// //         if (isValid) {
// //             console.log("Code 595783 for this number 09301234567 is valid and verified.");
// //         }
// //         else {
// //             console.log("Provided code for that number is not valid!");
// //         }
// //     })
// //     .catch(error => console.log(error));



// // client.manualSendCode("09138433385", "Verification Code: 595783 \nTrez WebService SMS")
// //     .then((messageId) => {
// //         console.log("Sent Message ID: " + messageId);
// //     })
// //     .catch(error => console.log(error));
// console.log("sallllll")